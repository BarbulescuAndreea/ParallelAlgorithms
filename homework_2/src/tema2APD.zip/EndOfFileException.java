public class EndOfFileException extends Exception {
}
