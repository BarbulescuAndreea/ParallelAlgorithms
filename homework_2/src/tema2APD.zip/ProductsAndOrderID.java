
public class ProductsAndOrderID {
    public String orderID;
    public String productID;

    public ProductsAndOrderID(String orderID, String productID) {
        this.orderID = orderID;
        this.productID = productID;
    }
}
